resource "azurerm_resource_group" "rg" {
  name     = "rg-${var.env}-kumar"
  location = var.location

  tags = {
    environment = var.env
    project     = "eduarn"
  }
}


output "printme" {
  value = azurerm_resource_group.rg
}

variable "env" {
  description = "Environment name"
  type        = string
  default= "demo-rg-kumar"
}

variable "location" {
  description = "Azure location"
  default     = "eastus"
}