data "azurerm_resource_group" "rg" {
  name = "avd-demo-rg"
}

data "azurerm_subnet" "subnet" {
  name                 = "avd-subnet"
  virtual_network_name = "avd-vnet"
  resource_group_name  = data.azurerm_resource_group.rg.name
}

data "azurerm_image" "image" {
  name                = "avd-image-1.0.0"
  resource_group_name = data.azurerm_resource_group.rg.name
}

resource "azurerm_network_interface" "nic" {
  name                = "avd-nic"
  location            = data.azurerm_resource_group.rg.location
  resource_group_name = data.azurerm_resource_group.rg.name

  ip_configuration {
    name                          = "internal"
    subnet_id                     = data.azurerm_subnet.subnet.id
    private_ip_address_allocation = "Dynamic"
  }
}

resource "azurerm_windows_virtual_machine" "vm" {
  name                = "avd-vm"
  location            = data.azurerm_resource_group.rg.location
  resource_group_name = data.azurerm_resource_group.rg.name
  size                = "Standard_B2s"

  admin_username = "azureuser"
  admin_password = "Test@987654321"

  network_interface_ids = [azurerm_network_interface.nic.id]

  source_image_id = data.azurerm_image.image.id

  os_disk {
    caching              = "ReadWrite"
    storage_account_type = "Standard_LRS"
  }
}